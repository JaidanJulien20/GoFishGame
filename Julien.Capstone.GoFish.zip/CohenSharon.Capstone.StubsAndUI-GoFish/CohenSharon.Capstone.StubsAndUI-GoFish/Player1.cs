﻿using CohenSharon.Capstone.Design;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CohenSharon.Capstone.StubsAndUI_GoFish
{
    public partial class Player1 : Form
    {
        private StartGame _game;
        private Player _player1;
        private Deal _cards;

        public Player1(Player one, Player two, Deal c)
        {
            InitializeComponent();
            _game = new StartGame(_cards, one, two);
            _player1 = one;
            // _cards = c;
        }

        //copy this player into the other player
        //stub everything out 
        //valid return values

        public void displayHand()
        {
            lstHandPlayer1.Items.Add(_player1.getHand());   //display the player's hand

        }


        //player selects a card to ask for(listbox)
        public string selectCardToAskFor()
        {
            // Get the selected card from the listbox
            string selectedCard = lstHandPlayer1.SelectedItem.ToString();
            return selectedCard;
        }


        //player1 calls method startGame and sends selected card - if the other player has the card
        private void callStartGame(string selectedCard)
        {
            _game.player0Turn(selectedCard);
        }


        // Call method in StartGame that checks other player's hand for the card
        private void checkOtherPlayerHand(string selectedCard)
        {
            _player1.doYouHaveAny(selectedCard);
        }


        //call countOccurances in player - returns the number of cards of that rank
        public int countOccurances(string selectedCard)
        {
            int cardCount = _player1.countOccurrences(selectedCard);
            return cardCount;
        }

        //if the number is 0, call goFish

        public void goFish(int cardCount)
        {
            if (cardCount == 0)
                _game.goFish();
        }

        //call removeCardFromHand other player - removes the card from the hand - returns hand without the cards

        // Call method in Player to remove the card from the hand
        private void removeCardFromHand(Player otherPlayer, string selectedCard)
        {
            otherPlayer.removeCardFromHand(selectedCard);
        }

        // Method to make the card disappear from the other player's hand and return them to this player
        public void makeCardDisappear(Player otherPlayer, string selectedCard, int cardCount)
        {
            // Remove the card from the other player's hand
            otherPlayer.removeCardFromHand(selectedCard);

            // Add the card to this player's hand
            _player1.addCardToHand(selectedCard, cardCount);
        }


        //call addCardToHand in player - adds the card to the hand - returns hand with the cards
        public void addCardToHand(string selectedCard, int cardCount)
        {
            _player1.addCardToHand(selectedCard, cardCount);
        }
        //check for books
        public void checkForBooks(string[] hand)
        {
            hand = _player1.getHand();
            _player1.checkForBooks(hand);
        }
        //Ask again
        public void playTurnAgain(string selectedCard)
        {
            _game.player0Turn(selectedCard);
        }


        private void lstHandPlayer1_SelectedIndexChanged(object sender, EventArgs e)
        {
            for (int n = 0; n < _player1._myHand.Length; n++)
            {
                // add items 
                lstHandPlayer1.Items.Add(_player1._myHand[n]);
                // add to controls 
                Controls.Add(lstHandPlayer1);
            }
        }

        private void lblCountBooks_Click(object sender, EventArgs e)
        {

        }

        private void btnEndTurn1_Click(object sender, EventArgs e)
        {

        }

        private void Player1_Load(object sender, EventArgs e)
        {

        }

        private void btnLoadHand_Click(object sender, EventArgs e)
        {
            for (int n = 0; n < _player1._myHand.Length; n++)
            {
                // add items 
                lstHandPlayer1.Items.Add(_player1._myHand[n]);
                // add to controls 
                Controls.Add(lstHandPlayer1);

            }

            btnLoadHand.Enabled = false;
            for (int n = 0; n < _player1._myHand.Length; n++)
            {
                if (_player1._myHand[n] != null)
                {
                    lstHandPlayer1.Items.Add(_player1._myHand[n]);
                    Controls.Add(lstHandPlayer1);
                }
            }
            btnLoadHand.Visible = false;
        }
    }
}
