﻿using System;

namespace CohenSharon.Capstone.Design
{
    public class Deal
    {
        private static String[] deckToDeal;
        private static int cardToDeal;
        private static String[] player0Hand = new String[22];
        private static String[] player1Hand = new String[22];

        private int numCardsInInitialHand = 7;

        public Deal()
        {
            setDeckToDeal();
            if (deckToDeal != null && deckToDeal.Length > 0)
            {
                dealInitialHand();
            }
        }

        public void setDeckToDeal()// this method imports a shuffled deck
        {
            Shuffle shuffledDeck = new Shuffle();
            deckToDeal = shuffledDeck.getTheShuffledDeck();
            if (deckToDeal == null)
            {
                // Handle the situation when theDeck is null in Shuffle class
                // For example, you can throw an exception or return from the method
            }
            if (deckToDeal.Length > 0)
            {
                initializeCardToDeal();
            }
        }

        //obtain a deckToDeal and shuffle it

        private void initializeCardToDeal()
        {
            cardToDeal = deckToDeal.Length - 1;
        }

        public void dealInitialHand()
        {
            for (int n = 0; n < numCardsInInitialHand; n++)
            {
                player0Hand[n] = deckToDeal[cardToDeal--];
                player1Hand[n] = deckToDeal[cardToDeal--];
            }
        }

        public String[] getPlayer0Hand()
        {
            return player0Hand;
        }

        public String[] getPlayer1Hand()
        {
            return player1Hand;
        }

        public String goFishCard()
        {
            if (cardToDeal > -1)
                return deckToDeal[cardToDeal--];
            else
                return null;
        }

        //modify numCardsInInitalHand if necessary

        //deal initial hand
        //create two arrays of length numCardsInInitialHand
        //populate those hands appropriately

        //go fish if deck is empty, return null
    }
}



