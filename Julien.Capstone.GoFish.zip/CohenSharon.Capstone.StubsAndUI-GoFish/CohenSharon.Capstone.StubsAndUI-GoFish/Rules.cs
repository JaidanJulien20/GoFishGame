﻿using System;

namespace CohenSharon.Capstone.Design
{
    public class Rules
    {
        private Deal deck;
        // game rules will be implemented here
        public Rules() { }

        public bool checkIfGoFishCardIsDrawnFromDeck(String askedCard, String goFishCard)
        {
            // Get the chosen card from the player

            // Check if the chosen card is in the deck
            if (askedCard.StartsWith(goFishCard))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public String goFish(String[] askingPlayerHand, Deal theCard)
        {
            // Get the player's hand

            // Get a card from the deck
            string card = theCard.goFishCard();

            // Add the card to the player's hand
            for (int n = 0; n < askingPlayerHand.Length; n++)
            {
                if (askingPlayerHand[n] == null)
                {
                    askingPlayerHand[n] = card;
                    break;
                }
            }

            return card;

        }

        public int giveCardToPlayerFromPlayer(String[] askedPlayerHand, String askedCard)
        {
            // Get the player's hand
            int cardCount = 0;

            // Get the chosen card from the player

            for (int n = 0; n < askedPlayerHand.Length; n++)
            {
                if (askedPlayerHand[n].StartsWith(askedCard))
                {
                    cardCount++;
                    askedPlayerHand[n] = null;
                }
            }
            return cardCount;
        }
        public bool checkForBooks(String[] hand)
        {
            int count = 0;
            for (int n = 0; n < hand.Length - 1; n++)
            {
                for (int m = n + 1; m < hand.Length; m++)
                {
                    if (hand[n] == hand[m])
                    {
                        count++;
                    }
                }
            }
            if (count == 6) // Assuming a book consists of 4 cards
            {
                return true;
            }
            return false;
        }

    }
}
