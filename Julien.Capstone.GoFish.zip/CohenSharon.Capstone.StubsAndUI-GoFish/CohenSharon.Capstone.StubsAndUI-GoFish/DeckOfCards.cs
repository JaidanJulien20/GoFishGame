﻿using System;

namespace DeckOfCardsTrue
{
    public class TheDeck
    {
        //attributes
        string[] theDeck;

        public TheDeck()
        {
            oneDeck();
        }

        public string[] getTheDeck()
        {
            return theDeck;
        }

        private void oneDeck()
        {
            initializeDeck();

            assignPictures();

            assignSuits();
        }

        private void initializeDeck()
        {
            theDeck = new String[52];

            for (int n = 0, m = 1; n < theDeck.Length; n++, m++)
            {
                if (m == 14)
                {
                    m = 1;
                }
                theDeck[n] = Convert.ToString(m);
            }
        }

        private void assignPictures()
        {
            for (int n = 0; n < theDeck.Length; n++)
            {
                switch (Convert.ToInt32(theDeck[n]))
                {
                    case 1:
                        theDeck[n] = "ace";
                        break;
                    case 11:
                        theDeck[n] = "jack";
                        break;
                    case 12:
                        theDeck[n] = "queen";
                        break;
                    case 13:
                        theDeck[n] = "king";
                        break;
                    default:
                        theDeck[n] = Convert.ToString(Convert.ToInt32(theDeck[n]));
                        break;
                }
            }
        }

        private void assignSuits()
        {
            for (int n = 0; n < theDeck.Length; n++)
            {
                switch (n / 13)
                {
                    case 0:
                        theDeck[n] += " clubs";
                        break;
                    case 1:
                        theDeck[n] += " diamonds";
                        break;
                    case 2:
                        theDeck[n] += " hearts";
                        break;
                    default:
                        theDeck[n] += " spades";
                        break;
                }
            }
        }

        public void showDeck(string[] theDeck)
        {
            {
                string outputString = "";

                for (int n = 0; n < theDeck.Length; n++)
                {
                    if (n % 13 == 0)
                    {
                        outputString += "\n";
                    }

                    outputString += theDeck[n] + ", ";
                }

                Console.WriteLine(outputString);
            }
        }
    }
}
