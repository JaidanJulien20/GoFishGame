﻿using CohenSharon.Capstone.Design;
using System;
using System.Windows.Forms;

namespace CohenSharon.Capstone.StubsAndUI_GoFish
{
    public partial class Player2 : Form
    {
        private StartGame _game;
        private Player _player0;
        private Deal _cards;

        public Player2(Player one, Player two)
        {
            InitializeComponent();
            _game = new StartGame(_cards, one, two);
        }

        //copy this player into the other player(done)
        //stub everything out (sort of done)
        //valid return values

        //display the player's hand

        //player selects a card to ask for(listbox)

        //player1 calls startGame method and sends selected card - if the other player has the card
        //call method in startGame - that checks other players hand for the card - send argument the selected card
        //call countOccurances in player - returns the number of cards of that rank
        //if the number is 0, call goFish
        //call removeCardFromHand other player - removes the card from the hand - returns hand without the cards
        //startGame must make the card disappear for the other player's hand - those carcs are returned to this player

        //call addCardToHand in player - adds the card to the hand - returns hand with the cards
        //check for books
        //Ask again
        //if player says go fish, call goFish
        //if player draws ask card, announce go fish
        //Ask again6
        //Other player turn

        private void lblGoFish_Click(object sender, EventArgs e)
        {

        }

        private void lblCountBooks_Click(object sender, EventArgs e)
        {

        }

        private void btnEndTurn1_Click(object sender, EventArgs e)
        {

        }

        private void btnLoadHand_Click(object sender, EventArgs e)
        {

            for (int n = 0; n < _player0._myHand.Length; n++)
            {
                // add items 
                lstHandPlayer2.Items.Add(_player0._myHand[n]);
                // add to controls 
                Controls.Add(lstHandPlayer2);

            }

            btnLoadHand.Enabled = false;
            for (int n = 0; n < _player0._myHand.Length; n++)
            {
                if (_player0._myHand[n] != null)
                {
                    lstHandPlayer2.Items.Add(_player0._myHand[n]);
                    Controls.Add(lstHandPlayer2);
                }
            }
            btnLoadHand.Visible = false;
        }
    }
}

