﻿using DeckOfCardsTrue;
using System;

namespace CohenSharon.Capstone
{
    public class Shuffle
    {
        //attributes
        string[] theShuffledDeck = null; // The array to store the shuffled deck
        string[] myDeck; // The array to store the original deck

        public Shuffle()
        {
            setTheDeck(); // Call the method to set the deck
        }

        private void setTheDeck()
        {
            TheDeck theDeck = new TheDeck(); // Create an instance of TheDeck class
            myDeck = theDeck.getTheDeck(); // Get the deck from TheDeck class
        }


        public string[] getTheShuffledDeck()
        {
            theShuffledDeck = shuffledDeck(); // Call the method to shuffle the deck

            return theShuffledDeck; // Return the shuffled deck
        }

        private void initializeShuffleTheDeck()
        {
            theShuffledDeck = new string[myDeck.Length]; // Initialize the shuffled deck array with the same length as the original deck
        }

        private string[] makeDisposableDeck()
        {
            string[] disposableDeck = new string[myDeck.Length]; // Create a disposable deck array with the same length as the original deck

            for (int n = 0; n < myDeck.Length; n++)
            {
                string toString = myDeck[n].ToString(); // Convert each card in the original deck to string
                disposableDeck[n] = toString; // Add the converted card to the disposable deck
            }
            return disposableDeck; // Return the disposable deck
        }

        private String[] shuffledDeck()
        {
            int eleNum;

            initializeShuffleTheDeck(); // Initialize the shuffled deck

            string[] disposableDeck = makeDisposableDeck(); // Create a disposable deck

            // loop through the deck randomly moving cards to the shuffled deck
            for (int n = 0; n < myDeck.Length; n++)
            {
                eleNum = obtainRandomNumber(disposableDeck.Length); // Get a random number within the range of the disposable deck length

                while (disposableDeck[eleNum] == ("-1")) // Check if the card at the random position is already moved to the shuffled deck
                {
                    eleNum++; // Move to the next position
                    if (eleNum == disposableDeck.Length) // If reached the end of the disposable deck, start from the beginning
                    {
                        eleNum = 0;
                    }
                }

                theShuffledDeck[n] = disposableDeck[eleNum]; // Move the card from disposable deck to the shuffled deck
                disposableDeck[eleNum] = "-1"; // Mark the moved card as "-1" in the disposable deck
            }
            return theShuffledDeck; // Return the shuffled deck
        }

        public int obtainRandomNumber(int length)
        {
            Random rand = new Random(); // Create a new instance of Random class
            return rand.Next(length); // Generate a random number within the specified length
        }
    }
}
