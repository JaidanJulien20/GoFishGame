﻿using CohenSharon.Capstone.StubsAndUI_GoFish;
using System;

namespace CohenSharon.Capstone.Design
{
    public class StartGame
    {
        private Deal _deal; // Represents the deal object
        private Shuffle _deck; // Represents the deck object
        private Player _player0; // Represents player 0
        private Player _player1; // Represents player 1

        //private AddPlayerNames _playAgain = new AddPlayerNames(); Do not need this line!!!!!!!!!


        public StartGame(Deal d, Player zero, Player one)
        {
            _deal = d; // Assign the deal object to the _deal field
            _player0 = zero; // Assign player 0 to the _player0 field
            _player1 = one; // Assign player 1 to the _player1 field
        }

        //Get a deck of cards
        public void obtainCardsFromDeck()
        {
            _deck.getTheShuffledDeck(); // Get the shuffled deck from the deck object
        }

        //Shuffle the deck
        //Deal the cards
        public void dealCards()
        {
            _deal.setDeckToDeal(); // Set the deck to deal from the deal object
            _deal.dealInitialHand(); // Deal the initial hand from the deal object
        }

        public void startGame()
        {
            _deal.getPlayer0Hand(); // Get player 0's hand from the deal object
            _deal.getPlayer1Hand(); // Get player 1's hand from the deal object
        }

        public void goFish()
        {
            _deal.goFishCard(); // Go fish a card from the deal object
        }

        public void setPlayerNames(String name0, String name1)
        {
            // AddPlayerNames playerNames = new AddPlayerNames();
            _player0.setPlayerName(name0); // Set player 0's name
            _player1.setPlayerName(name1); // Set player 1's name
        }

        public void player0Turn(String card)
        {
            Rules rules = new Rules();
            // Check if player 0 has the requested card
            if (_player1.doYouHaveAny(card) > 0)
            {
                // Get all the cards of the requested rank from player 0
                int numCards = _player1.doYouHaveAny(card);

                // Give the cards to the player who asked for them (player 0)
                _player1.removeCardFromHand(card);
                _player0.addCardToHand(card, numCards);

                // Check if player 0 has a set of four cards of the same rank
                if (_player0.checkForBooks(_player0._myHand))
                {
                    // Lay down the set of four cards
                    _player0.findBookInHand();
                    checkForWinner(_player0);
                }

                // Player 0 gets another turn
                player0Turn(card);
            }
            else
            {
                // Player 0 does not have the requested card, so they must Go Fish
                string goFishCard = _player0.goFish(_player0._myHand, _deal);

                _player0.findBookInHand();

                checkForWinner(_player0);

                // Check if the Go Fish card matches the rank of the requested card
                if (rules.checkIfGoFishCardIsDrawnFromDeck(card, goFishCard))
                {
                    // Player 0 keeps their turn
                    player0Turn(card);
                }
                else
                {
                    // Player 0's turn ends
                    player1Turn(card);
                }
            }
        }

        public void player1Turn(String card)
        {
            Rules rules = new Rules();
            // Check if player 0 has the requested card
            if (_player0.doYouHaveAny(card) > 0)
            {
                // Get all the cards of the requested rank from player 0
                int numCards = _player0.doYouHaveAny(card);

                // Give the cards to the player who asked for them (player 1)
                _player0.removeCardFromHand(card);
                _player1.addCardToHand(card, numCards);

                // Check if player 1 has a set of four cards of the same rank
                if (_player1.checkForBooks(_player1._myHand))
                {
                    // Lay down the set of four cards
                    _player1.findBookInHand();

                    checkForWinner(_player1);
                }

                // Player 1 gets another turn
                player1Turn(card);
            }
            else
            {
                // Player 1 does not have the requested card, so they must Go Fish
                string goFishCard = _player1.goFish(_player1._myHand, _deal);

                _player1.findBookInHand();

                checkForWinner(_player1);

                // Check if the Go Fish card matches the rank of the requested card
                if (rules.checkIfGoFishCardIsDrawnFromDeck(card, goFishCard))
                {
                    // Player 1 keeps their turn
                    player1Turn(card);
                }
                else
                {
                    // Player 1's turn ends
                    player0Turn(card);
                }
            }
        }

        public void playAgain(AddPlayerNames playAgain)
        {
            int startPlayer = playAgain._startPlayer; // Get the start player from the playAgain object
        }

        public void checkForWinner(Player player)
        {
            // Check if player 0 has 6 books
            int playerBooks = player.getnumBooks();
            if (playerBooks > 6)
            {
                AddPlayerNames playerNames = new AddPlayerNames();
                playerNames.ShowDialog(); // Show the player names dialog from the playerNames object
            }

            // No player has 7 books, game is not over
        }
        //Start the game
        //Person to the left of the dealer goes first
        //Start the turn by asking one player for a certain card
        //If the player has the card, the player must give all the cards of that rank to the asker
        //Take another turn if you get the cards you asked for
        //If the player does not have the card, the asker must Go Fish
        //Pick up one card from the deck
        //If go fish card matches the rank of the card asked for, the asker must keeps their turn
        //Lay down any sets of four to get them out of your hand
        //Take another turn after laying down the match
        //Game ends when someone has 7 or more books
        //Play again option
    }
}
